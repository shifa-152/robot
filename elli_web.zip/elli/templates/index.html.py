<!DOCTYPE html>
<html>
<head>
  <title>Elli Chat</title>
  <link rel="stylesheet" href="{{ url_for('static', filename='style.css') }}">
</head>
<body>
  <div class="chat-container">
    <h2>Elli - Your Memory Robot 🤖</h2>
    <div id="chat-box"></div>
    <input type="text" id="user-input" placeholder="Type something..." autocomplete="off">
    <button onclick="sendMessage()">Send</button>
  </div>

  <script>
    async function sendMessage() {
      const userInput = document.getElementById("user-input");
      const chatBox = document.getElementById("chat-box");

      let userText = userInput.value;
      if (!userText.trim()) return;

      chatBox.innerHTML += `<div class="user-msg">🧍‍♀️: ${userText}</div>`;
      userInput.value = "";

      const response = await fetch("/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: userText })
      });

      const data = await response.json();
      chatBox.innerHTML += `<div class="bot-msg">🤖: ${data.response}</div>`;
      chatBox.scrollTop = chatBox.scrollHeight;
    }
  </script>
</body>
</html>
