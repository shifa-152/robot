from flask import Flask, render_template, request, jsonify
from memory import remember, recall
import re

app = Flask(__name__)


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/chat", methods=["POST"])
def chat():
    user_input = request.json["message"].lower()

    # Handling memory storage
    if "remember that" in user_input:
        try:
            fact = user_input.split("remember that", 1)[1].strip()
            key = fact.split()[0]
            value = " ".join(fact.split()[1:])
            remember(key, value)
            return jsonify({"response": f"Okay, I'll remember that {key} is {value}."})
        except:
            return jsonify({"response": "Sorry, I couldn't understand what to remember."})

    elif "what do you remember about" in user_input:
        try:
            key = user_input.split("about", 1)[1].strip()
            info = recall(key)
            return jsonify({"response": f"You told me {key} is {info}."})
        except:
            return jsonify({"response": "Sorry, I didn't get that."})

    else:
        # Default dummy reply (you can improve this later)
        return jsonify({"response": "That's interesting! Tell me more or ask me something I should remember."})


if __name__ == "__main__":
    app.run(debug=True)
