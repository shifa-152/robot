body {
  font-family: 'Segoe UI', sans-serif;
  background-color: #f3f3f3;
  display: flex;
  justify-content: center;
  padding-top: 50px;
}

.chat-container {
  background: #fff;
  padding: 20px;
  width: 400px;
  border-radius: 15px;
  box-shadow: 0 0 10px rgba(0,0,0,0.1);
}

#chat-box {
  height: 300px;
  overflow-y: scroll;
  border: 1px solid #ddd;
  padding: 10px;
  margin-bottom: 10px;
  border-radius: 10px;
  background-color: #fafafa;
}

.user-msg {
  color: #000080;
  margin-bottom: 5px;
}

.bot-msg {
  color: #008000;
  margin-bottom: 10px;
}

input[type="text"] {
  width: 75%;
  padding: 8px;
}

button {
  padding: 8px 10px;
  background-color: #000080;
  color: white;
  border: none;
  cursor: pointer;
  border-radius: 5px;
}
